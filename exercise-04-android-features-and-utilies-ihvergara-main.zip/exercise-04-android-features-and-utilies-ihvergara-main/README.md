# Exercise 04: Android Features and Utilities
App/Program Description

### Name 
Ivyann Romijn H. Vergara
### Student Number
2020-00761
### Section
D-6L

## Screenshots

## Things you did in the code
Used the drawer navigation and the contacts

## Challenges faced
I had a hard time with the adding the contacts, was not able to finish. 

## Test Cases
Happy paths - Was able to run the code properly for navigation and the contact page update of data works.
Unhappy paths - Was not able to add new entries for contact lists. 

## References
