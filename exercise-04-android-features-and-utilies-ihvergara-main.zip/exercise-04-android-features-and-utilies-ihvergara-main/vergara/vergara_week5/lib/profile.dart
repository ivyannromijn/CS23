
import 'package:flutter/material.dart';

class ProfilePage extends StatelessWidget {
List<String> litems = ['Dancing', 'Cooking', 'Baking'];
  ProfilePage({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        children: <Widget>[
          Expanded(
            child: Container(
              color: const Color.fromRGBO(255, 179, 179, 100),
              child: Center(child: Image.asset('images/profilepic.jpg')),
            ),
          ),
          const Divider(
            height: 20,
            thickness: 5,
            indent: 20,
            endIndent: 0,
            color: Colors.grey,
          ),
          Expanded(
            child: Container(
              color: const Color.fromRGBO(255, 219, 164, 100),
              child: const Center(
                child: Text('Ivyann Romijn Vergara'),
              ),
            ),
          ),
          Expanded(
              child: Container(
            color: const Color.fromRGBO(255, 233, 174, 100),
            child: const Center(
              child: Text(
                'July 24, 2001',
              ),
            ),
          )),
          Expanded(
            child: Container(
              color: const Color.fromRGBO(193, 239, 255, 100),
              child: const Center(
                child:
                    Text('Angeles Heights Subdivision, San Pablo City, Laguna'),
              ),
            ),
          ),
          Expanded(
            child: Container(
              color: const Color.fromRGBO(175, 180, 255, 100),
              child: const Center(
                child: Text('Confidently Beautiful with a Heart'),
              ),
            ),
          ),
          Expanded(
            child: Container(
              color: const Color.fromRGBO(198, 235, 197, 100),
              child: ListView.builder(
                  itemCount: litems.length,
                  // ignore: non_constant_identifier_names
                  itemBuilder: (BuildContext ctxt, int Index) {
                    return Text(litems[Index],
                    style: TextStyle(color: Colors.black.withOpacity(0.6)));
                  })
            ),
              )
        ],
      ),
    );
  }
}
