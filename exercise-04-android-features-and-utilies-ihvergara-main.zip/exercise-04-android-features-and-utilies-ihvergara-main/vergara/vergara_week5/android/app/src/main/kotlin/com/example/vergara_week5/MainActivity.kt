package com.example.vergara_week5

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
