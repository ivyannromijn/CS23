import 'package:cloud_firestore/cloud_firestore.dart';

class FirebaseFriendAPI {
  static final FirebaseFirestore db = FirebaseFirestore.instance;

  Stream<QuerySnapshot> getAllFriend() {
    return db.collection("friends").snapshots();
  }

  // add to do method
  Future<String> addFriend(String id, String addId) async {
    try {
      await db.collection("friends").doc(id).update({
        'sentFriendRequests': FieldValue.arrayUnion([addId])
      });

      await db.collection("friends").doc(addId).update({
        'receivedFriendRequests': FieldValue.arrayUnion([id])
      });

      return "Successfully sent a friend! request";
    } on FirebaseException catch (e) {
      return "Failed with error '${e.code}: ${e.message}";
    }
  }

  Future<String> deleteFriend(String? id) async {
    try {
      await db.collection("friends").doc(id).delete();

      return "Successfully deleted friend!";
    } on FirebaseException catch (e) {
      return "Failed with error '${e.code}: ${e.message}";
    }
  }

  Future<String> acceptRequest(String? id, String accept_id) async {
    try {
      await db.collection("friends").doc(id).update({
        'friends': FieldValue.arrayUnion([accept_id])
      });

      await db.collection("friends").doc(accept_id).update({
        'friends': FieldValue.arrayUnion([id])
      });

      await db.collection("friends").doc(id).update({
        'receivedFriendRequests': FieldValue.arrayRemove([accept_id])
      });

      await db.collection("friends").doc(accept_id).update({
        'sentFriendRequests': FieldValue.arrayRemove([id])
      });

      return "Successfully accepted friend request!";
    } on FirebaseException catch (e) {
      return "Failed with error '${e.code}: ${e.message}";
    }
  }

  Future<String> declineRequest(String? id, String declineId) async {
    try {
      await db.collection("friends").doc(declineId).update({
        'sentFriendRequests': FieldValue.arrayRemove([id])
      });

      await db.collection("friends").doc(id).update({
        'receivedFriendRequests': FieldValue.arrayRemove([declineId])
      });

      return "Successfully declined friend request!";
    } on FirebaseException catch (e) {
      return "Failed with error '${e.code}: ${e.message}";
    }
  }

  Future<String> unfriendFriend(String? id, String friend_id) async {
    try {
      await db.collection("friends").doc(id).update({
        "friends": FieldValue.arrayRemove([friend_id])
      });

      await db.collection("friends").doc(friend_id).update({
        "friends": FieldValue.arrayRemove([id])
      });

      return "Successfully unfriended friend!";
    } on FirebaseException catch (e) {
      return "Failed with error '${e.code}: ${e.message}";
    }
  }
}
