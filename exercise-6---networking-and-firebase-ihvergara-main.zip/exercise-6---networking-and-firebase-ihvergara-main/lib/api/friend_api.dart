import 'dart:async';
import 'package:http/http.dart' as http;
import 'package:week7_networking_discussion/models/friend_model.dart';
//import 'package:week7_networking_discussion/api/friend_api.dart'

class FriendAPI {
  // return future list of friends
  Future<List<Friend>> fetchFriends() async {
    final response = await http.get(Uri.parse(
        'https://jsonplaceholder.typicode.com/friends')); // assign the content of the uri to response (an object)

    if (response.statusCode == 200) {
      // 200 = successful get (has a return value but can be empty)
      return Friend.fromJsonArray(response.body);
    } else {
      // If the server did not return a 200 OK response,
      // then throw an exception.
      throw Exception('Failed to load friends');
    }
  }
}
