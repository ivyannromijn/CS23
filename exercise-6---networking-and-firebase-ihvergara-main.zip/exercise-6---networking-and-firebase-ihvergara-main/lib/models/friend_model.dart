import 'dart:convert'; // list parser

class Friend {
  //final int userId;
  String id;
  String userName;
  String displayName;
  List friends;
  List receivedFriendRequests;
  List sentFriendRequests;

  // parse data (?)
  factory Friend.fromJson(Map<String, dynamic> json) {
    return Friend(
      //userId: json['userId'],
      id: json['id'],
      userName: json['userName'],
      displayName: json['displayName'],
      friends: json['friends'],
      receivedFriendRequests: json['receivedFriendRequests'],
      sentFriendRequests: json['sentFriendRequests'],
    );
  }

  Friend({
    //required this.userId,
    required this.id,
    required this.userName,
    required this.displayName,
    required this.friends,
    required this.receivedFriendRequests,
    required this.sentFriendRequests,
  });

  // list parses (from JSON array you will return a list of to do)
  static List<Friend> fromJsonArray(String jsonData) {
    final Iterable<dynamic> data = jsonDecode(jsonData);
    return data.map<Friend>((dynamic d) => Friend.fromJson(d)).toList();
  }

  Map<String, dynamic> toJson(Friend friend) {
    return {
      'id': friend.id,
      'userName': friend.userName,
      'displayName': friend.displayName,
      'friends': friend.friends,
      'receivedFriendRequests': friend.receivedFriendRequests,
      'sentFriendRequests': friend.sentFriendRequests,
    };
  }
}
