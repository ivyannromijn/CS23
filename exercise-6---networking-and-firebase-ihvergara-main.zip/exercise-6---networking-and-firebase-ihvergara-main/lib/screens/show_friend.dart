import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:week7_networking_discussion/screens/friend_page.dart';
import 'package:week7_networking_discussion/screens/modal_friend.dart';

class ShowFriendPage extends StatefulWidget {
  const ShowFriendPage({super.key});
  @override
  _ShowFriendPageState createState() => _ShowFriendPageState();
}

class _ShowFriendPageState extends State<ShowFriendPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
    );
  }
}
