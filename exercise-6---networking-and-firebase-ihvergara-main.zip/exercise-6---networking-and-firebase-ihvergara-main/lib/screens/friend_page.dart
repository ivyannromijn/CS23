import 'dart:math';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:week7_networking_discussion/main.dart';
import 'package:provider/provider.dart';
import 'package:week7_networking_discussion/models/friend_model.dart';
import 'package:week7_networking_discussion/providers/friend_provider.dart';
import 'package:week7_networking_discussion/screens/modal_friend.dart';
import 'package:week7_networking_discussion/api/firebase_friends_api.dart';

import 'package:cloud_firestore/cloud_firestore.dart';

class FriendPage extends StatefulWidget {
  const FriendPage({super.key});

  @override
  State<FriendPage> createState() => _FriendPageState();
}

class _FriendPageState extends State<FriendPage> {
  late Friend mainUser;
  List<Friend> friendsList = [];

  //String SampleId1 = '1';

  Icon customIcon = const Icon(Icons.search);
  Widget customSearchBar = const Text('User Profile');

  //  void searchOperation(String searchText) {
  //   searchresult.clear();
  //   if (_isSearching != null) {
  //     for (int i = 0; i < _list.length; i++) {
  //       String data = _list[i];
  //       if (data.toLowerCase().contains(searchText.toLowerCase())) {
  //         searchresult.add(data);
  //       }
  //     }
  //   }
  // }

  @override
  Widget build(BuildContext context) {
    // access the list of friends in the provider
    //Future<List<Friend>> futureFriends = context.watch<FriendListProvider>().friend;
    Stream<QuerySnapshot> friendsStream =
        context.watch<FriendListProvider>().friends;

    return Scaffold(
      appBar: AppBar(
        title: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Text('User Profile'),
          ],
        ),
        centerTitle: true,
      ),
      body: StreamBuilder(
        stream: friendsStream,
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(
              child: Text("Error encountered! ${snapshot.error}"),
            );
          } else if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(
              child: CircularProgressIndicator(),
            );
          } else if (!snapshot.hasData) {
            return Center(
              child: Text("No Friends Found"),
            );
          }

          List<Friend> users = [];
          int? usersLength = snapshot.data?.docs.length;
          if (usersLength != null) {
            for (int i = 0; i < usersLength; i++) {
              Friend user = Friend.fromJson(
                  snapshot.data?.docs[i].data() as Map<String, dynamic>);
              users.add(user);
            }
          }

          return Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                constraints: BoxConstraints.expand(
                  height:
                      Theme.of(context).textTheme.headline4!.fontSize! * 1.1 +
                          500.0,
                ),
                child: ListView.builder(
                  itemCount: snapshot.data?.docs.length,
                  itemBuilder: ((context, index) {
                    // Main user
                    Friend friend = Friend.fromJson(snapshot.data?.docs[index]
                        .data() as Map<String, dynamic>);
                    //print(friend);

                    mainUser = Friend.fromJson(
                        snapshot.data?.docs[0].data() as Map<String, dynamic>);

                    List<Friend> friendRequests = [];
                    List<Friend> addFriends = [];
                    List<Friend> friendsList = [];

                    //List<String> idList = [];

                    //add to friends
                    if (friend.friends.isNotEmpty) {
                      for (var friendsId in friend.friends) {
                        for (var friend in users) {
                          if (friendsId == friend.id) {
                            friendsList.add(friend);
                            //idList.add(friend.id);
                          }
                        }
                      }
                    }

                    //add to friend requests
                    if (friend.receivedFriendRequests.isNotEmpty) {
                      for (var requestsId in friend.receivedFriendRequests) {
                        for (var friend in users) {
                          if (requestsId == friend.id) {
                            friendRequests.add(friend);
                          }
                        }
                      }
                    }

                    //add to people you may know
                    for (var u in users) {
                      if (!friend.friends.contains(u.id) &&
                          !friend.sentFriendRequests.contains(u.id) &&
                          u.id != friend.id &&
                          !friend.receivedFriendRequests.contains(u.id)) {
                        addFriends.add(u);
                      }
                    }

                    if (index != 0) {
                      return Padding(
                        padding: const EdgeInsets.all(0),
                        child: Card(
                          child: Column(
                            children: [
                              if (!friend.receivedFriendRequests
                                      .contains(mainUser.id) &&
                                  !mainUser.friends.contains(friend.id) &&
                                  !friend.sentFriendRequests
                                      .contains(mainUser.id))
                                ListTile(
                                  title: Text(friend.displayName),
                                  trailing: ElevatedButton.icon(
                                    onPressed: () {
                                      context
                                          .read<FriendListProvider>()
                                          .changeSelectedFriend(mainUser);
                                      context
                                          .read<FriendListProvider>()
                                          .addFriend(friend.id);
                                    },
                                    icon: const Icon(
                                      // <-- Icon
                                      Icons.add,
                                      size: 24.0,
                                    ),
                                    label: Text('Add Friend'),
                                  ),
                                ),
                            ],
                          ),
                        ),
                      );
                    }
                    return Container(
                      margin: EdgeInsets.all(5),
                      padding: EdgeInsets.all(3),
                      child: Column(
                        children: [
                          Container(
                            width: 800,
                            height: 30,
                            child: TextField(
                              decoration: InputDecoration(
                                prefixIcon: const Icon(Icons.search),
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(50),
                                ),
                                hintText: 'Search A Friend',
                                hintStyle: const TextStyle(
                                  color: Color.fromARGB(255, 98, 94, 94),
                                  fontSize: 10,
                                ),
                              ),
                              //onChanged: searchOperation,
                            ),
                          ),
                          ListTile(
                            title: Text(
                              friend.displayName,
                              style: const TextStyle(
                                color: Colors.black,
                                fontWeight: FontWeight.w800,
                                fontFamily: 'Roboto',
                                fontSize: 20,
                              ),
                            ),
                            trailing: Text("Main User"),
                          ),
                          if (friendRequests.isEmpty)
                            Column(
                              children: [
                                Card(
                                  //elevation: 50,
                                  //shadowColor: Colors.black,
                                  color: Colors.white,
                                  child: SizedBox(
                                    height: 40,
                                    width: 2000,
                                    child: Padding(
                                      padding: const EdgeInsets.all(11.0),
                                      child: Column(
                                        children: [
                                          Text(
                                            "Friend Requests",
                                            style: const TextStyle(
                                                color: Colors.black,
                                                fontFamily: 'Roboto',
                                                fontSize: 15,
                                                fontWeight: FontWeight.bold),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: EdgeInsets.all(10),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: const [
                                      Text(
                                        "No Friend Requests",
                                        style: TextStyle(
                                          color: Colors.black,
                                          fontFamily: 'Roboto',
                                          fontSize: 13,
                                        ),
                                      )
                                    ],
                                  ),
                                ),
                                Card(
                                  //elevation: 50,
                                  //shadowColor: Colors.black,
                                  color: Colors.white,
                                  child: SizedBox(
                                    height: 40,
                                    width: 2000,
                                    child: Padding(
                                      padding: const EdgeInsets.all(11.0),
                                      child: Column(
                                        children: [
                                          Text(
                                            mainUser.displayName + "'s Friends",
                                            style: const TextStyle(
                                                color: Colors.black,
                                                fontFamily: 'Roboto',
                                                fontSize: 15,
                                                fontWeight: FontWeight.bold),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                                if (friendsList.isEmpty)
                                  Padding(
                                    padding: EdgeInsets.all(10),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Text(
                                          "No Friends",
                                          style: TextStyle(
                                            color: Colors.black,
                                            fontFamily: 'Roboto',
                                            fontSize: 13,
                                          ),
                                        )
                                      ],
                                    ),
                                  )
                                else
                                  Padding(
                                    padding: EdgeInsets.all(10),
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        for (var e in friendsList)
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: [
                                              Padding(
                                                padding: EdgeInsets.all(10),
                                                child: Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: [
                                                    Text(
                                                      e.displayName,
                                                      style: TextStyle(
                                                        color: Colors.black,
                                                        fontFamily: 'Roboto',
                                                        fontSize: 15,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              OutlinedButton(
                                                  onPressed: () {
                                                    context
                                                        .read<
                                                            FriendListProvider>()
                                                        .changeSelectedFriend(
                                                            mainUser);
                                                    context
                                                        .read<
                                                            FriendListProvider>()
                                                        .unfriendFriend(e.id);
                                                  },
                                                  child: Text("Unfriend"))
                                            ],
                                          )
                                      ],
                                    ),
                                  )
                              ],
                            )
                          else
                            Padding(
                              padding: EdgeInsets.all(2),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  for (var e in friendRequests)
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Padding(
                                          padding: EdgeInsets.all(10),
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: [
                                              Text(
                                                e.displayName,
                                                style: const TextStyle(
                                                  color: Colors.black,
                                                  fontFamily: 'Roboto',
                                                  fontSize: 15,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Padding(
                                          padding: EdgeInsets.all(5),
                                          child: OutlinedButton(
                                              onPressed: () {
                                                context
                                                    .read<FriendListProvider>()
                                                    .changeSelectedFriend(
                                                        mainUser);
                                                context
                                                    .read<FriendListProvider>()
                                                    .acceptRequest(e.id);
                                              },
                                              child: Text("Accept"),
                                              style: OutlinedButton.styleFrom(
                                                backgroundColor: Colors.green,
                                                primary: Colors.white,
                                              )),
                                        ),
                                        Padding(
                                          padding: EdgeInsets.all(5),
                                          child: OutlinedButton(
                                              onPressed: () {
                                                context
                                                    .read<FriendListProvider>()
                                                    .changeSelectedFriend(
                                                        mainUser);
                                                context
                                                    .read<FriendListProvider>()
                                                    .declineRequest(e.id);
                                              },
                                              child: Text("Decline"),
                                              style: OutlinedButton.styleFrom(
                                                backgroundColor: Colors.red,
                                                primary: Colors.white,
                                              )),
                                        ),
                                      ],
                                    ),
                                ],
                              ),
                            )
                        ],
                      ),
                    );
                  }),
                ),
              ),
            ],
          );
        },
      ),
      // floatingActionButton: FloatingActionButton(
      //   onPressed: () {
      //     showDialog(
      //       context: context,
      //       builder: (BuildContext context) => FriendModal(
      //         type: 'Add',
      //       ),
      //     );
      //   },
      //   child: const Icon(Icons.add_outlined),
      // ),
    );
  }
}
