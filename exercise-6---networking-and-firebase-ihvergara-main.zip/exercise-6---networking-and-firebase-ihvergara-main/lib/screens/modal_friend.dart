import 'dart:math';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:week7_networking_discussion/models/friend_model.dart';
import 'package:week7_networking_discussion/providers/friend_provider.dart';
import 'package:week7_networking_discussion/screens/show_friend.dart';

class FriendModal extends StatelessWidget {
  String type;
  //int friendIndex;
  TextEditingController _formFieldController = TextEditingController();

  FriendModal({super.key, required this.type});

  // Method to show the title of the modal depending on the functionality
  Text _buildTitle() {
    switch (type) {
      case 'Search':
        return const Text("Search a friend");
      case 'Add':
        return const Text("Add new friend");
      case 'Edit':
        return const Text("Edit friend");
      case 'Delete':
        return const Text("Delete friend");
      default:
        return const Text("");
    }
  }

  // Method to build the content or body depending on the functionality
  Widget _buildContent(BuildContext context) {
    // Use context.read to get the last updated list of friends
    // List<Friend> friendItems = context.read<FriendListProvider>().friend;

    switch (type) {
      // case 'Delete':
      //   {
      //     return Text(
      //       "Are you sure you want to delete '${context.read<FriendListProvider>().selected.title}'?",
      //     );
      //   }
      // Edit and add will have input field in them
      default:
        return TextField(
          controller: _formFieldController,
          decoration: InputDecoration(
            border: const OutlineInputBorder(),
            // hintText: friendIndex != -1 ? friendItems[friendIndex].title : '',
          ),
        );
    }
  }

  TextButton _searchButton(BuildContext context) {
    return TextButton(
      onPressed: () {
        switch (type) {
          case 'Search':
            {
              context.read<FriendListProvider>().fetchFriends();

              // Remove dialog after adding
              Navigator.of(context).push(MaterialPageRoute(
                builder: (context) => const ShowFriendPage(),
              ));
              //break;
            }
        }
      },
      style: TextButton.styleFrom(
        textStyle: Theme.of(context).textTheme.labelLarge,
      ),
      child: Text(type),
    );
  }

  TextButton _dialogAction(BuildContext context) {
    // List<Friend> friendItems = context.read<FriendListProvider>().friend;

    return TextButton(
      onPressed: () {
        switch (type) {
          // case 'Search':
          //   {
          //     // context.read<FriendListProvider>().searchFriend();
          //     //  .editFriend(friendIndex, _formFieldController.text);

          //     // Remove dialog after editing
          //     // Navigator.of(context).pop();
          //     // break;
          //   }
          // case 'Add':
          //   {
          //     // Modify the add method to call the provider method
          //     Friend temp = Friend(
          //         userId: 1,
          //         completed: false,
          //         title: _formFieldController.text);
          //     context.read<FriendListProvider>().addFriend(temp);
          //     Navigator.of(context).pop();

          //     break;
          //   }
          case 'Edit':
            {
              context.read<FriendListProvider>();
              //.editFriend(friendIndex, _formFieldController.text);

              // Remove dialog after editing
              Navigator.of(context).pop();
              break;
            }
          case 'Delete':
            {
              context.read<FriendListProvider>().deleteFriend();

              Navigator.of(context).pop();
              break;
            }
        }
      },
      style: TextButton.styleFrom(
        textStyle: Theme.of(context).textTheme.labelLarge,
      ),
      child: Text(type),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: _buildTitle(),
      content: _buildContent(context),

      // Contains two buttons - add/edit/delete, and cancel
      actions: <Widget>[
        _dialogAction(context),
        TextButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          child: Text("Cancel"),
          style: TextButton.styleFrom(
            textStyle: Theme.of(context).textTheme.labelLarge,
          ),
        ),
      ],
    );
  }
}
