import 'package:flutter/material.dart';
import 'package:week7_networking_discussion/models/friend_model.dart';
import 'package:week7_networking_discussion/api/friend_api.dart';
import 'package:week7_networking_discussion/api/firebase_friends_api.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:EXERCISE6_VERGARA/api/friend_api.dart';
// import 'package:EXERCISE6_VERGARA/api/firebase_friends_api.dart';

class FriendListProvider with ChangeNotifier {
  //late FriendAPI friendAPI;
  //late Future<List<Friend>> _friendList;
  late FirebaseFriendAPI firebaseService;
  late Stream<QuerySnapshot> _friendsStream;
  Friend? _selectedFriend;

  FriendListProvider() {
    firebaseService = FirebaseFriendAPI();
    fetchFriends();
  }

  Stream<QuerySnapshot> get friends => _friendsStream;

  Friend get selected => _selectedFriend!;
  changeSelectedFriend(Friend friend) {
    _selectedFriend = friend;
  }

  fetchFriends() {
    _friendsStream = firebaseService.getAllFriend();
    notifyListeners();
  }

  void addFriend(String add_id) async {
    String message =
        await firebaseService.addFriend(_selectedFriend!.id, add_id);
    print(message);

    notifyListeners();
  }

  void editFriend(int index, String newTitle) {
    //_friendList[index].title = newTitle;
    notifyListeners();
  }

  void deleteFriend() async {
    String message = await firebaseService.deleteFriend(_selectedFriend!.id);
    print(message);
    notifyListeners();
  }

  void toggleStatus(int index, bool status) {
    //_friendList[index].completed = status;
    notifyListeners();
  }

  void acceptRequest(String acceptId) async {
    String message =
        await firebaseService.acceptRequest(_selectedFriend!.id, acceptId);
    print(message);
    print("ME:" + _selectedFriend!.id);
    print("ADDID:" + acceptId);
    notifyListeners();
  }

  void declineRequest(String declineId) async {
    String message =
        await firebaseService.declineRequest(_selectedFriend!.id, declineId);
    print(message);
    notifyListeners();
  }

  void unfriendFriend(String friend_id) async {
    String message =
        await firebaseService.unfriendFriend(_selectedFriend!.id, friend_id);
    print(message);
    notifyListeners();
  }

  // void searchFriend() async{
  //   String message = await firebaseService.searchFriend(_selectedFriend!.id);
  //   notifyListeners();
  // }
}
