class Person {
  String firstName;
  String lastName;
  Person(this.firstName, this.lastName);
  String get fullName => "$firstName $lastName";
  String get initials => "${firstName[0]}. ${lastName[0]}.";

  set fullName (String fullName) {
    var parts = fullName.split(" ");     // returns a list
    this.firstName = parts.first;
    this.lastName = parts.last;
  }
}

class Student extends Person {
  String nickName;
  Student(String firstName, String lastName, this.nickName)
  : super(firstName, lastName);
  //@override
  //String toString() => "$fullName, also known as $nickName";
}

main() {
  Student student = new Student("Clark", "Kent", "Kal-El");
  print(student.toString());            // same as calling student.toString() 
}
