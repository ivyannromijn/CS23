class Subject{
  String courseNum;
  String title;
  Subject? prereq;
  
  
  Subject(this.courseNum, this.title, this.prereq);
  
  
}