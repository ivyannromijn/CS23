import 'package:exer1_oop_in_dart/Student.dart';
import 'package:exer1_oop_in_dart/Subject.dart';

class Section{
  
  String sectionName;
  Subject subject;
  final maxSTUDENT=5;
  List<Student> maxStudents=[];

  Section(this.sectionName,this.subject);
 

  void addStudent(Student allStudent) {
    if (maxStudents.length!=maxSTUDENT){
      print("Student added!");
      maxStudents.add(stud);
    }else{
      print("Student cannot be added! Section is full!");
    }
  }

  void searchStudent(String s) {}

  void printStudents() {
    print("STUDENTS IN ${this.sectionName}");
    for (var i=0; i<maxStudents.length;i++){
      print(maxStudents[i].printStudentDetails());
    }
  }

 getMeanGWA() {

  }
}