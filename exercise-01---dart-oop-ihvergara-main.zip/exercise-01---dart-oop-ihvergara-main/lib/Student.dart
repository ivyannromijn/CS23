// ignore: file_names
import 'Subject.dart';

class Student{
  String? studentName;
  int? age;
  String? studentnum;
  String? course;
  double? gwa;
  List<Subject> subjectsTaken=[];
  Student(String this.studentName, int this.age, String this.studentnum, String this.course, double this.gwa);

  
 
  void printStudentDetails() {
    print("studentName: ${this.studentName}");
    print("age: ${this.age}");
    print("student number: ${this.studentnum}");
    print("course: ${this.course}");
    print("gwa: ${gwa}");
    print("Subjects taken:");

    for (var i=0; i<subjectsTaken.length; i++){
      if
      
    }


  }



