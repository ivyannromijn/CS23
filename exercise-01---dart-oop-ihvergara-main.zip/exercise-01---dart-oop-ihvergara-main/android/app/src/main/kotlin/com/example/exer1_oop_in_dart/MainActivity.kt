package com.example.exer1_oop_in_dart

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
