# Exercise 01: OOP in Dart
App/Program Description

### Ivyann Romijn Vergara
### 2020-00761
### D-6L

## Screenshots
Since the exercise is terminal-based, add screenshots of the outputs per feature.

## Things you did in the code
I tried making classes first and then make the contructor proceeded with making the methods needed. 


## Challenges faced
Needed to refresh my knowledge in OOP since I really had a hard time because I forgot the basic concepts. 

## Test Cases


## References
