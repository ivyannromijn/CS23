# flutter_contacts_example

Demonstrates how to use the flutter_contacts plugin.