package co.quis.flutter_contacts_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
