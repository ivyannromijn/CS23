#import <Flutter/Flutter.h>

@interface FlutterContactsPlugin : NSObject<FlutterPlugin>
@end
