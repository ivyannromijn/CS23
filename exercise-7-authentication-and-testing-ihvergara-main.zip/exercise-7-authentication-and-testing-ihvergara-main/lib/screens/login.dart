// ignore_for_file: library_private_types_in_public_api

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:week7_networking_discussion/providers/auth_provider.dart';
import 'package:week7_networking_discussion/screens/signup.dart';
import 'package:flutter/gestures.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  @override
  Widget build(BuildContext context) {
    TextEditingController emailController = TextEditingController();
    TextEditingController passwordController = TextEditingController();
    final _formKey = GlobalKey<FormState>();

    final form = Form(
      key: _formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            margin: EdgeInsets.all(3),
            padding: EdgeInsets.all(3),
            child: TextFormField(
                key: const Key('emailFieldLogIn'),
                controller: emailController,
                decoration: InputDecoration(
                  // ignore: prefer_const_constructors
                  prefixIcon: Icon(Icons.email),
                  // ignore: prefer_const_constructors
                  contentPadding: EdgeInsets.all(10.0),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(50),
                  ),
                  hintText: "Email",
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Enter email address.';
                  }
                  if (value.contains(RegExp(
                          r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+")) ==
                      false) {
                    return 'Email address should be in the following format: juan@email.com';
                  }
                }),
          ),
          Container(
            //margin: EdgeInsets.all(5),
            padding: EdgeInsets.all(3),
            child: TextFormField(
                key: const Key('pwFieldLogIn'),
                controller: passwordController,
                obscureText: true,
                decoration: InputDecoration(
                  prefixIcon: Icon(Icons.lock),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(50),
                  ),
                  hintText: 'Password',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Enter password.';
                  }
                  if (value.length < 6) {
                    return 'Password is too weak. It should be at least six characters.';
                  }
                }),
          ),
        ],
      ),
    );

    // final email = TextFormField(
    //   key: const Key('emailFieldLogIn'),
    //   controller: emailController,
    //   decoration: const InputDecoration(
    //     hintText: "Email",
    //   ),
    // );

    // final password = TextFormField(
    //   key: const Key('pwFieldLogIn'),
    //   controller: passwordController,
    //   obscureText: true,
    //   decoration: const InputDecoration(
    //     hintText: 'Password',
    //   ),
    // );

    final loginButton = Padding(
      key: const Key('loginButton'),
      padding: const EdgeInsets.symmetric(vertical: 16.0),
      child: MaterialButton(
        minWidth: double.infinity,
        height: 60,
        onPressed: () async {
          if (_formKey.currentState!.validate()) {
            String error = "";
            await context
                .read<AuthProvider>()
                .signIn(emailController.text, passwordController.text)
                .then((String result) {
              error = result;
            });
            if (error != "") {
              ScaffoldMessenger.of(context)
                  .showSnackBar(SnackBar(content: Text(error)));
            }
          }
          // contextF
          //     .read<AuthProvider>()
          //     .signIn(emailController.text, passwordController.text);
        },
        color: Color(0xff0095FF),
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(50),
        ),
        child: const Text('Log In',
            style: TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 18,
                color: Colors.white)),
      ),
    );

    final signUpButton = Padding(
      key: const Key('signUpButton'),
      padding: const EdgeInsets.symmetric(vertical: 16.0),
      child: RichText(
        textAlign: TextAlign.center,
        text: TextSpan(children: [
          TextSpan(
              text: 'Do not have an account? ',
              style: TextStyle(
                color: Colors.black,
              )),
          TextSpan(
              text: "Sign Up",
              style: TextStyle(
                color: Colors.blue,
                fontWeight: FontWeight.bold,
              ),
              recognizer: TapGestureRecognizer()
                ..onTap = () async {
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (context) => const SignupPage(),
                    ),
                  );
                }),
        ]),
        // onPressed: () async {
        //   Navigator.of(context).push(
        //     MaterialPageRoute(
        //       builder: (context) => const SignupPage(),
        //     ),
        //   );
        // },
        //child: const Text('Sign Up', style: TextStyle(color: Colors.white)),
      ),
    );
    final design = Container(
      key: const Key('design_login'),
      padding: EdgeInsets.only(top: 100),
      height: 200,
      decoration: BoxDecoration(
        image: DecorationImage(
            image: AssetImage("assets/background.png"), fit: BoxFit.fitHeight),
      ),
    );
    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: Colors.white,
      // appBar: AppBar(
      //   elevation: 0,
      //   brightness: Brightness.light,
      //   backgroundColor: Colors.white,
      //   leading: IconButton(
      //     onPressed: () {
      //       Navigator.pop(context);
      //     },
      //     icon: Icon(
      //       Icons.arrow_back_ios,
      //       size: 20,
      //       color: Colors.black,
      //     ),
      //   ),
      // ),
      body: Center(
        child: ListView(
          shrinkWrap: true,
          padding: const EdgeInsets.only(left: 40.0, right: 40.0),
          children: <Widget>[
            Text(
              "Login",
              style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            Text(
              "Login to your account",
              style: TextStyle(fontSize: 15, color: Colors.grey[700]),
              textAlign: TextAlign.center,
            ),
            form,
            loginButton,
            signUpButton,
            design,
          ],
        ),
      ),
    );
  }
}
