import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:week7_networking_discussion/main.dart' as app;

void main() {
  // Define a test
  testWidgets('Happy Path Widget 2 ', (tester) async {
    // Create the widget by telling the tester to build it.
    app.main();

    expect(find.text('Login'), findsOneWidget);
    expect(find.text('Login to your account'), findsOneWidget);
    expect(find.byKey(const Key("emailFieldLogIn")), findsOneWidget);
    expect(find.byKey(const Key("pwFieldLogIn")), findsOneWidget);
    expect(find.byKey(const Key("loginButton")), findsOneWidget);
    expect(find.byKey(const Key("signUpButton")), findsOneWidget);
    expect(find.byKey(const Key("design_login")), findsOneWidget);
    await tester.enterText(find.byKey(const Key("emailFieldLogIn")), "hotdog");
    expect(find.text('hotdog'), findsOneWidget);
    await tester.tap(find.byKey(const Key("loginButton")));
    await tester.pump();
    // expects that there is an first name field on the log in page
    expect(
        find.text(
            "Email address should be in the following format: juan@email.com"),
        findsOneWidget);
  });
}
