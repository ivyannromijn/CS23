import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:week7_networking_discussion/main.dart' as app;

void main() {
  // Define a test
  testWidgets('Unhappy Path Widget 1 ', (tester) async {
    // Create the widget by telling the tester to build it.
    app.main();

    expect(find.text('Login'), findsOneWidget);
    expect(find.text('Login to your account'), findsOneWidget);
    expect(find.byKey(const Key("emailFieldLogIn")), findsOneWidget);
    expect(find.byKey(const Key("pwFieldLogIn")), findsOneWidget);
    expect(find.byKey(const Key("loginButton")), findsOneWidget);
    expect(find.byKey(const Key("signUpButton")), findsOneWidget);
    expect(find.byKey(const Key("design_login")), findsOneWidget);

    // expects that there is an first name field on the log in page
    expect(find.byKey(const Key("fNameField")), findsOneWidget);
  });
}
