import 'package:flutter/material.dart';

class GWAForm extends StatefulWidget {
  GWAForm({super.key});

  @override
  _GWAFormState createState() => _GWAFormState();
}

class _GWAFormState extends State<GWAForm> {
  final _GWAFormKey = GlobalKey<FormState>();

  // list of values for the GWA
  static final List<String> _gwaOptions = [
    "1",
    "1.25",
    "1.5",
    "1.75",
    "2",
    "2.25",
    "2.5",
    "2.75",
    "3",
    "5"
  ];

  final List<String> unitsOptions = ["1", "2", "3", "4", "5"];

  static bool summaryClicked = false;

  Map<String, dynamic> formValues = {
    'dropdownValue': _gwaOptions.first,
  };

  // will store the values of the user's input per row
  static List<String> subjectText = [""];
  static List<String> dropdownValue = [_gwaOptions.first];
  static List<String> unitsValue = [""];
  static List<Widget> subjectList = [];

  static int counter = 1;
  bool isComputed = false;

  get index => 0;

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _GWAFormKey,
      child: ListView(
        children: [
          Column(
            children: [
              subjects(index),
              Column(
                  children:
                      subjectList), // succeeding rows upon add button clicked
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  ElevatedButton(
                    onPressed: () {
                      setState(() {
                        // adds a new row (subject)
                        _addSubjectWidget();
                      });
                    },
                    child: const Text('ADD SUBJECT'),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      setState(() {
                        // will dictate whether summary will be shown
                        summaryClicked = !summaryClicked;
                      });
                    },
                    child: const Text('COMPUTE'),
                  ),
                ],
              ),
              showSummary(),
              Center(
                  child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  primary: Colors.brown,
                ),
                onPressed: () {
                  // reset button
                  setState(() {
                    resetButton();
                  });
                },
                child: const Text('RESET'),
              )),
            ],
          ),
        ],
      ),
    );
  }

  void _addSubjectWidget() {
    // initialize another values for the following list and update the counter
    subjectList.add(subjects(counter));
    dropdownValue.add(_gwaOptions.first);
    unitsValue.add("");
    subjectText.add("");
    counter++;

    for (int i = 0; i < counter; i++) {
      print(
          "SUBJECT: ${subjectText[i]} | GRADE: ${dropdownValue[i]} | UNITS: ${unitsValue[i]}");
    }
  }

  Widget subjects(index) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Container(
          margin: const EdgeInsets.only(left: 10.0, right: 10.0, top: 15.0),
          child: Row(
            children: [
              // add the subject with the current index as the parameter
              Expanded(flex: 2, child: subjectForm(index)),
              Expanded(flex: 1, child: gradesForm(index)),
              Expanded(flex: 1, child: unitsForm(index))
            ],
          ),
        ),
      ],
    );
  }

  // this will be the first column of the row (input field for subject)
  Widget subjectForm(index) {
    return (Column(
      children: [
        Row(
          children: [
            Text(
              "Subject",
              style: TextStyle(
                color: Colors.black,
                fontSize: 18,
              ),
            ),
          ],
        ),
        TextFormField(
          decoration: const InputDecoration(
            border: OutlineInputBorder(),
          ),
          onChanged: ((String value) {
            subjectText[index] = value;
          }),
        ),
      ],
    ));
  }

  // this will be the second column of the row (dropdown for the grades)
  Widget gradesForm(index) {
    return (Column(
      children: [
        DecoratedBox(
          decoration: BoxDecoration(
            color: Colors.pink[50],
            border: Border.all(color: Colors.black, width: 3),
          ),
        ),
        Row(
          children: [
            Text(
              "Grade",
              style: TextStyle(
                color: Colors.black,
                fontSize: 18,
              ),
            ),
          ],
        ),
        Container(
          margin: EdgeInsets.only(left: 11, right: 11),
          padding: EdgeInsets.all(5),
          decoration: BoxDecoration(color: Colors.pink[100]),
          child: FormField(
            builder: (FormFieldState<String> state) {
              return DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                  style: TextStyle(
                    color: Colors.black,
                    fontWeight: FontWeight.bold,
                  ),
                  value: dropdownValue[index],
                  onChanged: (String? value) {
                    setState(() {
                      dropdownValue[index] = value!;
                    });
                  },
                  items: _gwaOptions.map<DropdownMenuItem<String>>(
                    (String value) {
                      return DropdownMenuItem<String>(
                        value: value,
                        child: Text(value),
                      );
                    },
                  ).toList(),
                ),
              );
            },
          ),
        ),
      ],
    ));
  }

  // this will be the last column of the row (input field for the units)
  Widget unitsForm(index) {
    return (Column(
      children: [
        Row(
          children: [
            Text(
              "Units",
              style: TextStyle(
                color: Colors.black,
                fontSize: 18,
              ),
            ),
          ],
        ),
        TextFormField(
          decoration: const InputDecoration(
            border: OutlineInputBorder(),
          ),
          onChanged: ((String value) {
            unitsValue[index] = value;
          }),
        ),
      ],
    ));
  }

  // shows the summary
  Widget showSummary() {
    // check if the button is clicked and all the necessary fields are not empty
    if (summaryClicked && dataExists()) {
      return Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            decoration: BoxDecoration(
              color: Colors.pink[50],
              borderRadius: BorderRadius.circular(20),
            ),
            padding: const EdgeInsets.all(30),
            margin: const EdgeInsets.symmetric(vertical: 50),
            child: Column(
              children: [
                const Text(
                  "Summary",
                  style: TextStyle(
                    fontSize: 25,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Row(
                      children: [
                        // show all data
                        eachSubjectData(subjectText),
                        eachSubjectData(dropdownValue),
                        eachSubjectData(unitsValue),
                      ],
                    )
                  ],
                ),
                Column(
                  children: [
                    Row(
                      children: [
                        Container(
                          margin: EdgeInsets.only(right: 20),
                          child: Text(
                            "GWA",
                            style: TextStyle(
                                fontSize: 27, fontWeight: FontWeight.w700),
                          ),
                        ),
                        showGWA(),
                        showResult()
                      ],
                    ),
                  ],
                )
              ],
            ),
          ),
        ],
      );
    } else {
      print("Complete data first");
      return Text("");
    }
  }

  // computes for the GWA
  Widget showGWA() {
    double total = calculateGWA();

    return (Column(
      children: [
        Text(
          total.toString(),
          style: TextStyle(
            fontSize: 27,
            fontWeight: FontWeight.w700,
          ),
        )
      ],
    ));
  }

 Widget showResult(){
  String? result = findResult();

    return (Column(
      children: [
        Text(
          result!,
          style: TextStyle(
            fontSize: 27,
            fontWeight: FontWeight.w700,
          ),
        )
      ],
    ));
 }
  // show all data of each column
  Widget eachSubjectData(List<String> data) {
    return (Container(
      margin: EdgeInsets.all(20),
      child: Column(
        children: data
            .map(
              (item) => Container(
                margin: EdgeInsets.all(10),
                child: Text(
                  item,
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            )
            .toList(),
      ),
    ));
  }

  // converts the units and grades into double before calculating the GWA
  static double calculateGWA() {
    double total = 0;
    double temp = 0;
    var units;
    var grade;
    double totalUnits = 0;
    for (var i = 0; i < counter; i++) {
      units = double.parse(unitsValue[i]);
      assert(units is double);
      print("UNITS: $units");

      grade = double.parse(dropdownValue[i]);
      assert(grade is double);
      print("GRADE: $grade");

      temp = units * grade;

      totalUnits += units;
      total += temp;
    }

    print(total);

    return total / totalUnits;
  }

  static String? findResult(){
    double total1 = calculateGWA();
    String? result;
    if (total1 >= 1 && total1<=1.45){
      print("You are a university scholar!");
      result ="You are a university scholar!";
    }
    

    return result;
  }

  // returns false when all are empty or the input for units is invalid
  bool dataExists() {
    for (var i = 0; i < counter; i++) {
      if ((dropdownValue[i] == "" ||
              unitsValue[i] == "" ||
              subjectText[i] == "") ||
          !unitsOptions.contains(unitsValue[i])) {
        return false;
      }
    }

    return true;
  }

  // resets all lists so that it is empty
  void resetButton() {
    subjectText = [""];
    dropdownValue = [_gwaOptions.first];
    unitsValue = [""];
    subjectList = [];
    counter = 0;
  }
}
