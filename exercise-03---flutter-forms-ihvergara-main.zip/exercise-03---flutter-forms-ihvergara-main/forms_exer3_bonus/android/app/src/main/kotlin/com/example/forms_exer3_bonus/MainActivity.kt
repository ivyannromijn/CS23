package com.example.forms_exer3_bonus

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
