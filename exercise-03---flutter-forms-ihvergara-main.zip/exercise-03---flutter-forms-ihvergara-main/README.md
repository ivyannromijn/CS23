# Exercise 03: Flutter Forms
App/Program Description

### Name 
Ivyann Romijn H. Vergara
### Student Number
2020-00761
### Section
D-6L

## Screenshots

## Things you did in the code
I made the widgets for subjects, grades, units separately and then put them into a parent (form) widget. Created a method for adding subjects, GWA

## Challenges faced
I had a hard time with the emulator and installation of flutter. When I installed it properly, it takes a long time to run. 

## Test Cases
Happy paths - Was able to run the code properly, it works as said on the specification.

Was able to add the bonus option. 

Unhappy paths - Planned to add a bonus function (show whether the student is US or not) but did not have enough time. Wasn't able to improve the UI experience. 

## References
https://rrtutors.com/tutorials How-to-add-Widget-dynamically-on-button-click-flutter
https://api.flutter.dev/flutter/material/Colors-class.html
https://techpilipinas.com/compute-gwa-calculator/#:~:text=the%20honor%20roll.-,How%20to%20Compute%20Your%20GWA,the%20semester%20or%20school%20year.
