# Exercise 02: UI, Widgets, and Layouts
App/Program Description

### Ivyann Romijn Vergara
### 2020-00761
### D-6L

## Screenshots
Since the exercise is terminal-based, add screenshots of the outputs per feature.

## Things you did in the code
Made stateless widgets


## Challenges faced
Took a time in dynamic list

## Test Cases


## References

