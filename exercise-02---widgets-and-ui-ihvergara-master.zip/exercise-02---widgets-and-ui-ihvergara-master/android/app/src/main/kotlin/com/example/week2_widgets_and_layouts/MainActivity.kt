package com.example.week2_widgets_and_layouts

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
