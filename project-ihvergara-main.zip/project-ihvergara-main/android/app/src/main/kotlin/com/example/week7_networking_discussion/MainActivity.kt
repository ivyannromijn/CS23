package com.example.week7_networking_discussion

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
