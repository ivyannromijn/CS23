# Exercise 7

The todo app connects to firebase cloud firestore and authentication. It uses a provider for state management. 

## Folder Structure
```
lib
├───api
│   └───firebase_auth_api.dart*
│   └───firebase_todo_api.dart
├───models
│   └───todo_model.dart
├───providers
│   └───todo_provider.dart
│   └───auth_provider.dart*
├───screens
│   ├───modal_todo.dart
│   └───todo_page.dart
│   └───login.dart*
│   └───signup.dart*
└───main.dart
```

* Models - contains the data model used
* Providers - contains the Todo provider that contains the data and method logic
* Screens - contains the screen/widgets used

## Happy Paths
* widget_test.dart - Shows the expected widgets upon clicking sign up button
* widget3_test.dart -Was able to validate the email with a proper format

## Unhappy Paths
* widget2_test.dart - Expects a name textfield on the login page (Should be email and password only)
* widget4_test.dart - Cannot read the input of the user email in log in page