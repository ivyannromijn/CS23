// ignore_for_file: camel_case_types

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:week7_networking_discussion/screens/todo_page.dart';

import '../providers/auth_provider.dart';
import 'friendsPage.dart';
import 'profilePage.dart';

class settingsPage extends StatefulWidget {
  const settingsPage({super.key});

  @override
  State<settingsPage> createState() => _settingsPageState();
}

class _settingsPageState extends State<settingsPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings'),
      ),
      drawer: Drawer(
        child: ListView(
            // Important: Remove any padding from the ListView.
            padding: EdgeInsets.zero,
            children: [
              ListTile(
                title: const Text('Todo'),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const TodoPage()),
                  );
                },
              ),
              ListTile(
                title: const Text('Profile'),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => const profilePage()),
                  );
                },
              ),
              ListTile(
                title: const Text('Friends'),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => const friendsPage()),
                  );
                },
              ),
              ListTile(
                title: const Text('Logout'),
                onTap: () {
                  context.read<AuthProvider>().signOut();
                  Navigator.popUntil(context, ModalRoute.withName('/'));
                },
              ),
            ]),
      ),
    );
  }
}
