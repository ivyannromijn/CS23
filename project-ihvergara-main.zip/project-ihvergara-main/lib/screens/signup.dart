import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:week7_networking_discussion/providers/auth_provider.dart';

class SignupPage extends StatefulWidget {
  const SignupPage({super.key});
  @override
  _SignupPageState createState() => _SignupPageState();
}

class _SignupPageState extends State<SignupPage> {
  @override
  Widget build(BuildContext context) {
    TextEditingController emailController = TextEditingController();
    TextEditingController passwordController = TextEditingController();
    TextEditingController fNameController = TextEditingController();
    TextEditingController lNameController = TextEditingController();
    TextEditingController bdayController = TextEditingController();
    TextEditingController locController = TextEditingController();
    final _formKey = GlobalKey<FormState>();

    final form = Form(
      key: _formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            margin: EdgeInsets.all(5),
            padding: EdgeInsets.all(3),
            child: TextFormField(
                key: const Key("emailField"),
                controller: emailController,
                decoration: InputDecoration(
                  prefixIcon: Icon(Icons.email),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(50),
                  ),
                  hintText: "Email",
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Enter email address.';
                  }
                  if (value.contains(RegExp(
                          r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+")) ==
                      false) {
                    return 'Email address should be in the following format: juan@email.com';
                  }
                }),
          ),
          Container(
            margin: EdgeInsets.all(5),
            padding: EdgeInsets.all(3),
            child: TextFormField(
                key: const Key('pwField'),
                controller: passwordController,
                obscureText: true,
                // style: const TextStyle(fontFamily: "Lato"),
                decoration: InputDecoration(
                  prefixIcon: Icon(Icons.lock),
                  // hintStyle: TextStyle(fontFamily: "Lato"),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(50),
                  ),
                  hintText: 'Password',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Enter password.';
                  }
                  if (value.length < 6) {
                    return 'Password is too weak. It should be at least six characters.';
                  }
                }),
          ),
          Container(
            margin: EdgeInsets.all(5),
            padding: EdgeInsets.all(3),
            child: TextFormField(
                key: const Key('fNameField'),
                controller: fNameController,
                // style: const TextStyle(fontFamily: "Lato"),
                decoration: InputDecoration(
                  prefixIcon: Icon(Icons.person),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(50),
                  ),
                  // hintStyle: TextStyle(fontFamily: "Lato"),
                  hintText: "First Name",
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Enter first name.';
                  }
                }),
          ),
          Container(
            margin: EdgeInsets.all(5),
            padding: EdgeInsets.all(3),
            child: TextFormField(
                key: const Key('lNameField'),
                controller: lNameController,
                // style: const TextStyle(fontFamily: "Lato"),
                decoration: InputDecoration(
                  prefixIcon: Icon(Icons.person),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(50),
                  ),
                  // hintStyle: TextStyle(fontFamily: "Lato"),
                  hintText: "Last Name",
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Enter last name.';
                  }
                }),
          ),
          Container(
            margin: EdgeInsets.all(5),
            padding: EdgeInsets.all(3),
            child: TextFormField(
                //focusNode: AlwaysDisabledFocuseNode(),
                key: const Key('bdayField'),
                controller: bdayController,
                // style: const TextStyle(fontFamily: "Lato"),
                decoration: InputDecoration(
                  prefixIcon: Icon(Icons.calendar_today),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(50),
                  ),
                  // hintStyle: TextStyle(fontFamily: "Lato"),
                  hintText: "Enter Birthday",
                ),
                readOnly: true,
                onTap: () async {
                  var date = await showDatePicker(
                      context: context,
                      initialDate: DateTime.now(),
                      firstDate: DateTime(1900),
                      lastDate: DateTime(2100));
                  bdayController.text = date.toString().substring(0, 10);
                },
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Enter your birthday.';
                  }
                }),
          ),
          Container(
            margin: EdgeInsets.all(5),
            padding: EdgeInsets.all(3),
            child: TextFormField(
                key: const Key('locField'),
                controller: locController,
                // style: const TextStyle(fontFamily: "Lato"),
                decoration: InputDecoration(
                  prefixIcon: Icon(Icons.location_on),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(50),
                  ),
                  // hintStyle: TextStyle(fontFamily: "Lato"),
                  hintText: "Location",
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Enter your location.';
                  }
                }),
          ),
        ],
      ),
    );

    // final email = TextField(
    //   controller: emailController,
    //   decoration: const InputDecoration(
    //     hintText: "Email",
    //   ),
    // );

    // final password = TextField(
    //   controller: passwordController,
    //   obscureText: true,
    //   decoration: const InputDecoration(
    //     hintText: 'Password',
    //   ),
    // );

    final SignupButton = Padding(
      key: const Key('signUpButton'),
      padding: const EdgeInsets.symmetric(vertical: 16.0),
      child: MaterialButton(
        minWidth: double.infinity,
        height: 60,
        onPressed: () {
          if (_formKey.currentState!.validate()) {
            String error = "";
            context
                .read<AuthProvider>()
                .signUp(
                    emailController.text,
                    passwordController.text,
                    fNameController.text,
                    lNameController.text,
                    bdayController.text,
                    locController.text)
                .then((String result) {
              error = result;
            });
            if (error != "") {
              ScaffoldMessenger.of(context)
                  .showSnackBar(SnackBar(content: Text(error)));
            } else {
              Navigator.pop(context);
            }
          }
        },
        color: Color(0xff0095FF),
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(50),
        ),
        child: const Text('Sign up',
            style: TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 18,
                color: Colors.white)),
      ),
    );

    final backButton = Padding(
      key: const Key('backButton'),
      padding: const EdgeInsets.symmetric(vertical: 16.0),
      child: FloatingActionButton(
        child: Icon(Icons.arrow_back),
        backgroundColor: Color(0xff0095FF),
        foregroundColor: Colors.white,
        onPressed: () async {
          Navigator.pop(context);
        },
        //child: const Text('Back', style: TextStyle(color: Colors.white)),
      ),
    );
    final design2 = Container(
      key: const Key('design_signup'),
      padding: EdgeInsets.only(top: 100),
      height: 200,
      decoration: BoxDecoration(
        image: DecorationImage(
            image: AssetImage("assets/welcome.png"), fit: BoxFit.fitHeight),
      ),
    );
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: ListView(
          shrinkWrap: true,
          padding: const EdgeInsets.only(left: 40.0, right: 40.0),
          children: <Widget>[
            design2,
            const Text(
              "Sign up",
              style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            Text(
              "Create your account",
              style: TextStyle(fontSize: 15, color: Colors.grey[700]),
              textAlign: TextAlign.center,
            ),
            form,
            SignupButton,
            backButton
          ],
        ),
      ),
    );
  }
}
