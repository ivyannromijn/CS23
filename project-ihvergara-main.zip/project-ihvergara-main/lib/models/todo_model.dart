/*
  Created by: Claizel Coubeili Cepe
  Date: 27 October 2022
  Description: Sample todo app with networking
*/

import 'dart:convert';

class Todo {
  final int userId;
  String? id;
  String title;
  String desc;
  bool completed;
  String dl;

  Todo({
    required this.userId,
    this.id,
    required this.title,
    this.completed = false,
    required this.desc,
    required this.dl,
  });

  // Factory constructor to instantiate object from json format
  factory Todo.fromJson(Map<String, dynamic> json) {
    return Todo(
      userId: json['userId'],
      id: json['id'],
      title: json['title'],
      desc: json['desc'],
      completed: json['completed'],
      dl: json['deadline'],
    );
  }

  static List<Todo> fromJsonArray(String jsonData) {
    final Iterable<dynamic> data = jsonDecode(jsonData);
    return data.map<Todo>((dynamic d) => Todo.fromJson(d)).toList();
  }

  Map<String, dynamic> toJson(Todo todo) {
    return {
      'userId': todo.userId,
      'title': todo.title,
      'desc': todo.desc,
      'completed': todo.completed,
      'deadline': todo.dl
    };
  }
}
