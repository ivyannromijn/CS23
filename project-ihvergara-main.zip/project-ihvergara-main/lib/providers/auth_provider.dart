import 'dart:async';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:week7_networking_discussion/api/firebase_auth_api.dart';

class AuthProvider with ChangeNotifier {
  late FirebaseAuthAPI authService;
  User? userObj;

  AuthProvider() {
    authService = FirebaseAuthAPI();
    authService.getUser().listen((User? newUser) {
      userObj = newUser;
      print('AuthProvider - FirebaseAuth - onAuthStateChanged - $newUser');
      notifyListeners();
    }, onError: (e) {
      // provide a more useful error
      print('AuthProvider - FirebaseAuth - onAuthStateChanged - $e');
    });
  }

  User? get user => userObj;

  bool get isAuthenticated {
    return user != null;
  }

  Future<String> signIn(String email, String password) async {
    String error = await authService.signIn(email, password);
    print(error);
    return (error);
  }

  signOut() {
    authService.signOut();
  }

  Future<String> signUp(String email, String password, String fName,
      String lName, String bday, String loc) async {
    String error =
        await authService.signUp(email, password, fName, lName, bday, loc);
    return (error);
  }
}
